export enum Estado {
  PENDIENTE = 0,
  IMPRESO_MITAD = 1,
  IMPRESO_COMPLETO = 2,
  LISTO = 3,
  RETIRADO = 4,
  CANCELADO = 5,
  STOCK = 6,
  CONSTRUCCION = '7',
  POR_CONFIRMAR = '8'
}