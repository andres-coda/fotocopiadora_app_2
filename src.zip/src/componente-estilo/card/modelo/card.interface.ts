import { MouseEventHandler, ReactNode } from "react";

export interface CardProp {
  chica?: boolean | undefined;
  listo?: boolean | undefined;
  pendiente?: boolean | undefined;
  retirado?: boolean | undefined;
  ruta?: string | undefined;
  onClick?: MouseEventHandler<HTMLDivElement> | undefined;
  nuevoEstilo?: string | undefined;
}

export interface CardPropComp extends CardProp {
  children: ReactNode;
  ultActualizacion?: string | undefined;
  tituloCard?: string;
}